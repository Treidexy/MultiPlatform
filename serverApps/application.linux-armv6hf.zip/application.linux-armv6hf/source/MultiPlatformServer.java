import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.net.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class MultiPlatformServer extends PApplet {



// Edit these values in config.json
String map = "";
String gameMode = "";

Server s;
Client c;
ArrayList<Client> clients = new ArrayList<Client>();
String cInput, inputs[], data[];
int framesNoFeedback = 0;

ArrayList<Player> players = new ArrayList<Player>();
int selId;

ArrayList<Shot> shots = new ArrayList<Shot>();

final boolean showErr = false;

final float
  pWidth = 50, 
  pHeight = 100, 
  pCrouchHeight = 50;
int
  screenHeight = 1250, 
  screenWidth = 800;

public void setup() {
  
  frameRate(60);
  
  parseConfig();

  s = new Server(this, 6969);

  surface.setTitle("Multi Platform | Server - " + Server.ip());
}
public void draw() {
  framesNoFeedback++;      


  background(217);
  if (framesNoFeedback >= 60) {
    text("Waiting for Players...", width/2, height/2 - 45);
  }

  parseData();

  fill(151);
  textSize(50);
  textAlign(CENTER, CENTER);
  textSize(40);
  text("IP: " + Server.ip(), width/2, height/2 + 45);

  for (int i = 0; i < shots.size(); i++)
    shots.get(i).update();
  for (int i = 0; i < players.size(); i++) {
    players.get(i).inActiveFrames++;
    if (players.get(i).inActiveFrames > 300) {
      disposeClient(i);
    }
  }
}

public void serverEvent(Server server, Client client) {
  try {
    clients.add(client);
    client.write("id " + (clients.size() - 1) + "\n");
    client.write("setting " + map + " " + gameMode + "\n");

    players.add(new Player(clients.size() - 1));

    for (int i = 0; i < clients.size(); i++) {
      if (clients.get(i).active())
        clients.get(i).write("pc " + clients.size() + "\n");
    }

    while (clients.size() > 4) {
      disposeClient(clients.size() - 1);
    }
  } 
  catch (Exception e) {
    if (showErr)
      System.err.println(e);
  }
}

public void disposeClient(int id) {
  clients.remove(id);
  players.remove(id);

  for (int l = 0; l < clients.size(); l++) {
    clients.get(l).write("id " + l + "\n");
    clients.get(l).write("dc " + id + "\n");
    players.get(l).setId(l);
  }
}
public void parseConfig() {
  try {
    JSONObject config = loadJSONObject("config.json");

    map = config.getString("map");
    gameMode = config.getString("game-mode");
  } 
  catch (Exception e) {
    System.err.println("Can't read config.json!");
  }
}
public void parseData() {
  for (int i = 0; i < clients.size(); i++) {
    c = clients.get(i);
    try {
      background(69);

      text(players.size() + " player(s) active", width/2, height/2 - 45);

      framesNoFeedback = 0;

      selId = i;

      cInput = c.readString();
      inputs = cInput.split("\n");

      for (String input : inputs) {
        String pubMsg = null; 
        String[] data = split(input, ' ');

        if (data[0].equals(String.valueOf(selId))) {
          pubMsg = "c " + selId + " " + data[1] + " " + data[2] + " " + players.get(selId).health + " " + data[3] + " " + data[4];

          players.get(selId).setPos(PApplet.parseInt(data[1]), PApplet.parseInt(data[2]));
          players.get(selId).isCrouching = PApplet.parseBoolean(data[3]);
          players.get(selId).facingLeft = PApplet.parseBoolean(data[4]);
          players.get(selId).inActiveFrames = 0;
        }

        switch (data[0]) {
        case "shot":
          shots.add(new Shot(PApplet.parseInt(data[1]), PApplet.parseInt(data[2]), PApplet.parseBoolean(data[3]), PApplet.parseInt(data[4]), PApplet.parseInt(data[5])));
          pubMsg = input;
          break;
        case "dc":
          disposeClient(PApplet.parseInt(data[1]));
          pubMsg = input;
          break;
        }

        for (int l = 0; l < clients.size(); l++)
          clients.get(l).write(pubMsg + "\n");
      }
    } 
    catch(Exception e) {
      if (showErr)
        System.err.println(e);
    }
  }
}
class Player {
  final static int ADD = 1, SUB = -1;
  int
    x, 
    y, 
    health, 
    id;
  int inActiveFrames = 0;
  boolean isCrouching, facingLeft;

  Player(int id) {
    this.id = id;

    health = 20;
  }

  public void health(int operation, int value) {
    switch(operation) {
    case ADD:
      health += value;
      break;
    case SUB:
      health -= value;
      break;
    }
    for (int l = 0; l < clients.size(); l++)
      clients.get(l).write("cp " + id + " hp " + health + "\n");
      println("cp " + id + " hp " + health + "\n");
  }

  public void setPos(int nx, int ny) {
    x = nx;
    y = ny;
  }

  public void setId(int value) {
    id = value;
  }
}
class Shot {
  int player;
  int damage;
  boolean facingLeft;
  int x, 
    y, 
    w, 
    h;
  final int speed;

  Shot(int player, int damage, boolean facingLeft, int x, int y) {
    this.player = player;
    this.damage = damage;
    this.facingLeft = facingLeft;
    this.x = x;
    this.y = y;

    switch(damage) {
    case 1:
      w = 48;
      h = 16;
      speed = 9;
      break;
    case 2:
      w = 48;
      h = 16;
      speed = 7;
      break;
    case 3:
      w = 48;
      h = 16;
      speed = 5;
      break;
    case 4:
      w = 48;
      h = 16;
      speed = 3;
      break;

    default:
      w = 48;
      h = 16;
      speed = 7;
    }
  }

  public void update() {
    if (facingLeft)
      x-= speed;
    else
      x+= speed;

    if (x < -w)
      shots.remove(this);
    if (x > screenWidth)
      shots.remove(this);

    for (int i = 0; i < clients.size(); i++) {
      if (collidingWithPlayer(players.get(i)) && i != player) {
        players.get(i).health(Player.SUB, damage);
        shots.remove(this);
      }
    }
  }

  public boolean collidingWithPlayer(Player _p) {
    if (x + w > _p.x && x < _p.x + pWidth && y + h > _p.y && y < _p.y + pHeight)
      return true;
    return false;
  }
}
  public void settings() {  size(500, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "MultiPlatformServer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
